package cse.web;
//log class to track login id and type
public class logs {
     public static String Uid="";
     public static String Utp="";

}
